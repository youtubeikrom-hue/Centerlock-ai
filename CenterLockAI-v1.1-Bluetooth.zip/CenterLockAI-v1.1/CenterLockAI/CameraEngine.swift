import AVFoundation
import Vision
import CoreImage
import Photos
import UIKit
import SwiftUI

final class CameraEngine: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate {
    @Published private(set) var preview: UIImage?
    @Published private(set) var targetRect: CGRect?
    @Published private(set) var edgeLimited = false
    @Published private(set) var status = "Kamera tayyorlanmoqda"
    @Published private(set) var recording = false
    @Published private(set) var saving = false
    @Published private(set) var elapsedText = "00:00"
    @Published private(set) var landscape = false
    @Published private(set) var fps = 30
    @Published private(set) var zoom = 1.6
    @Published private(set) var smooth = false
    @Published var message: String?
    private let session = AVCaptureSession()
    private let queue = DispatchQueue(label:"centerlock.capture", qos:.userInitiated)
    private let video = AVCaptureVideoDataOutput()
    private let audio = AVCaptureAudioDataOutput()
    private let ci = CIContext(options:[.cacheIntermediates:false])
    private var device: AVCaptureDevice?
    private var configured = false
    private var micEnabled = false
    private var observation: VNDetectedObjectObservation?
    private var sequence = VNSequenceRequestHandler()
    private var crop = CGRect(x:0,y:0,width:1,height:1)
    private var center = CGPoint(x:0.5,y:0.5)
    private var qZoom: CGFloat = 1.6
    private var qSmooth = false
    private var qLandscape = false
    private var qFPS = 30
    private var writer: MovieWriter?
    private var wantRecord = false
    private var firstPTS: CMTime?
    private var lastPreview = CMTime.invalid
    private var lost = false
    private var interrupted = false
    private var observers: [NSObjectProtocol] = []
    override init() {
        super.init()
        let nc = NotificationCenter.default
        observers.append(nc.addObserver(forName:.AVCaptureSessionWasInterrupted,object:session,queue:nil) { [weak self] _ in self?.queue.async { self?.interrupted = true; self?.finish(); self?.ui { $0.status = "Kamera vaqtincha band" } } })
        observers.append(nc.addObserver(forName:.AVCaptureSessionInterruptionEnded,object:session,queue:nil) { [weak self] _ in self?.queue.async { self?.interrupted = false; self?.ui { $0.status = "Tayyor" } } })
        observers.append(nc.addObserver(forName:.AVCaptureSessionRuntimeError,object:session,queue:nil) { [weak self] n in let msg = (n.userInfo?[AVCaptureSessionErrorKey] as? Error)?.localizedDescription ?? "Kamera xatosi"; self?.queue.async { self?.finish(); self?.ui { $0.message = msg } } })
    }
    deinit { observers.forEach { NotificationCenter.default.removeObserver($0) } }
    private func ui(_ block: @escaping (CameraEngine)->Void) { DispatchQueue.main.async { [weak self] in if let self { block(self) } } }
    @MainActor func prepare() async {
        let allowed = await AVCaptureDevice.requestAccess(for:.video)
        guard allowed else { status = "Kamera ruxsati yo‘q"; message = "Settings → Privacy & Security → Camera orqali ruxsat bering."; return }
        let mic = await AVCaptureDevice.requestAccess(for:.audio)
        queue.async { [weak self] in self?.configure(mic:mic) }
    }
    private func configure(mic:Bool) {
        if configured { if !session.isRunning { session.startRunning() }; return }
        guard let cam = AVCaptureDevice.default(.builtInWideAngleCamera,for:.video,position:.back), let input = try? AVCaptureDeviceInput(device:cam) else { ui{$0.status="Kamera topilmadi"};return }
        session.beginConfiguration()
        session.sessionPreset = .inputPriority
        guard session.canAddInput(input),session.canAddOutput(video) else { session.commitConfiguration(); ui{$0.status="Kamera konfiguratsiya xatosi"};return }
        session.addInput(input)
        device = cam
        video.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA]
        video.alwaysDiscardsLateVideoFrames = true
        video.setSampleBufferDelegate(self,queue:queue)
        session.addOutput(video)
        if mic,let m = AVCaptureDevice.default(for:.audio),let mi = try? AVCaptureDeviceInput(device:m),session.canAddInput(mi),session.canAddOutput(audio) {
            session.addInput(mi);session.addOutput(audio);audio.setSampleBufferDelegate(self,queue:queue);micEnabled=true
        }
        applyFormat()
        orient()
        session.commitConfiguration()
        configured = true
        session.startRunning()
        ui { $0.status = "Obyektni belgilang" }
    }
    private func orient() {
        if let c = video.connection(with:.video),c.isVideoOrientationSupported { c.videoOrientation = qLandscape ? .landscapeRight : .portrait }
        if let c = video.connection(with:.video),c.isVideoStabilizationSupported { c.preferredVideoStabilizationMode = .off }
    }
    private func applyFormat() {
        guard let d=device else{return}
        let candidates = d.formats.filter { f in
            let s=CMVideoFormatDescriptionGetDimensions(f.formatDescription)
            return s.width >= 1920 && s.height >= 1080 && abs(Double(s.width)/Double(s.height)-16.0/9.0)<0.03 && f.videoSupportedFrameRateRanges.contains { $0.minFrameRate <= Double(qFPS) && $0.maxFrameRate >= Double(qFPS) }
        }.sorted { a,b in
            let x=CMVideoFormatDescriptionGetDimensions(a.formatDescription),y=CMVideoFormatDescriptionGetDimensions(b.formatDescription)
            return Int64(x.width)*Int64(x.height)>Int64(y.width)*Int64(y.height)
        }
        guard let format=candidates.first else { if qFPS != 30 { qFPS=30; ui{$0.fps=30;$0.message="60 FPS mavjud emas. 30 FPS tanlandi."};applyFormat() } else { ui{$0.message="Tanlangan kamera formati mavjud emas."} };return }
        do { try d.lockForConfiguration(); defer{d.unlockForConfiguration()};d.activeFormat=format;let duration=CMTime(value:1,timescale:Int32(qFPS));d.activeVideoMinFrameDuration=duration;d.activeVideoMaxFrameDuration=duration;if d.isFocusModeSupported(.continuousAutoFocus){d.focusMode = .continuousAutoFocus};if d.isExposureModeSupported(.continuousAutoExposure){d.exposureMode = .continuousAutoExposure} } catch { ui{$0.message=error.localizedDescription} }
    }
    func changeFPS(_ value:Int) { guard !recording && !saving else{return};fps=value;queue.async{self.qFPS=value;guard self.configured else{return};self.session.beginConfiguration();self.applyFormat();self.orient();self.session.commitConfiguration();self.reset() } }
    func toggleFormat() { guard !recording && !saving else{return};landscape.toggle();let value=landscape;preview=nil;queue.async{self.qLandscape=value;self.orient();self.reset()} }
    func changeZoom(_ value:Double){zoom=value;queue.async{self.qZoom=CGFloat(value)}}
    func changeSmooth(_ value:Bool){smooth=value;queue.async{self.qSmooth=value}}
    func clearTarget(){queue.async{self.reset()}}
    private func reset(){observation=nil;sequence=VNSequenceRequestHandler();center=CGPoint(x:0.5,y:0.5);crop=CGRect(x:0,y:0,width:1,height:1);lost=false;ui{$0.targetRect=nil;$0.edgeLimited=false;$0.status="Obyektni belgilang"}}
    func select(_ r:CGRect){queue.async{
        let mapped=CGRect(x:self.crop.minX+r.minX*self.crop.width,y:self.crop.minY+r.minY*self.crop.height,width:r.width*self.crop.width,height:r.height*self.crop.height).intersection(CGRect(x:0,y:0,width:1,height:1))
        guard mapped.width>0.01,mapped.height>0.01 else{return}
        self.sequence=VNSequenceRequestHandler();self.observation=VNDetectedObjectObservation(boundingBox:mapped);self.center=CGPoint(x:mapped.midX,y:mapped.midY);self.lost=false
    }}
    func resume(){queue.async{if self.configured && !self.session.isRunning {self.session.startRunning()}}}
    func suspend(){queue.async{self.finish();if self.session.isRunning {self.session.stopRunning()}}}
    func startRecording(){ guard !recording && !saving else{return};recording=true;elapsedText="00:00";queue.async{guard self.configured,!self.interrupted else{self.ui{$0.recording=false};return};self.wantRecord=true;self.firstPTS=nil} }
    func stopRecording(){queue.async{self.finish()}}
    private func finish(){
        guard wantRecord || writer != nil else{return};wantRecord=false;let w=writer;writer=nil;firstPTS=nil
        ui{$0.recording=false;$0.saving=(w != nil)}
        guard let w else{return}
        w.finish { [weak self] result in
            switch result {
            case .failure(let error): self?.ui{$0.saving=false;$0.message=error.localizedDescription}
            case .success(let url):
                PHPhotoLibrary.requestAuthorization(for:.addOnly){ auth in
                    guard auth == .authorized || auth == .limited else {self?.ui{$0.saving=false;$0.message="Photos ruxsati yo‘q. Fayl Files → CenterLock AI ichida saqlandi."};return}
                    PHPhotoLibrary.shared().performChanges({PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL:url)}){ success,error in
                        if success {try? FileManager.default.removeItem(at:url)}
                        self?.ui{$0.saving=false;$0.message=success ? "Video Photos’ga saqlandi!" : "Video Files → CenterLock AI ichida saqlandi. \(error?.localizedDescription ?? "")"}
                    }
                }
            }
        }
    }
    func captureOutput(_ output:AVCaptureOutput,didOutput sampleBuffer:CMSampleBuffer,from connection:AVCaptureConnection){
        if output === audio { writer?.appendAudio(sampleBuffer);return }
        guard let pixel=CMSampleBufferGetImageBuffer(sampleBuffer),!interrupted else{return}
        let pts=CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        if let obs=observation {
            let req=VNTrackObjectRequest(detectedObjectObservation:obs);req.trackingLevel = .accurate
            do {try sequence.perform([req],on:pixel,orientation:.up);if let next=req.results?.first as? VNDetectedObjectObservation,next.confidence>=0.40,next.boundingBox.width>0.008,next.boundingBox.height>0.008 {observation=next} else {observation=nil;lost=true}} catch {observation=nil;lost=true}
        }
        let tracking=observation != nil
        let factor:CGFloat=(tracking || lost) ? qZoom : 1
        let size=1/factor
        if let b=observation?.boundingBox {
            let alpha:CGFloat=qSmooth ? 0.32 : 1
            center.x += (b.midX-center.x)*alpha;center.y += (b.midY-center.y)*alpha
        }
        let cx=min(1-size/2,max(size/2,center.x)),cy=min(1-size/2,max(size/2,center.y))
        crop=CGRect(x:cx-size/2,y:cy-size/2,width:size,height:size)
        let limited=tracking && (abs(cx-center.x)>0.006 || abs(cy-center.y)>0.006)
        let src=CIImage(cvPixelBuffer:pixel),e=src.extent
        let region=CGRect(x:e.minX+crop.minX*e.width,y:e.minY+crop.minY*e.height,width:crop.width*e.width,height:crop.height*e.height)
        let image=src.cropped(to:region).transformed(by:CGAffineTransform(translationX:-region.minX,y:-region.minY))
        let outW=qLandscape ? 1920 : 1080, outH=qLandscape ? 1080 : 1920
        if wantRecord {
            do {
                if writer == nil {writer=try MovieWriter(width:outW,height:outH,fps:qFPS,audio:micEnabled);firstPTS=pts}
                try writer?.appendVideo(image,pts:pts,context:ci)
                if let start=firstPTS {let s=max(0,Int(CMTimeGetSeconds(pts-start)));ui{$0.elapsedText=String(format:"%02d:%02d",s/60,s%60)}}
            } catch {writer?.cancel();writer=nil;wantRecord=false;ui{$0.recording=false;$0.saving=false;$0.message=error.localizedDescription}}
        }
        if !lastPreview.isValid || CMTimeGetSeconds(pts-lastPreview)>=1.0/24.0 || pts<lastPreview {
            lastPreview=pts
            let scale=min(1,640/max(image.extent.width,image.extent.height));let small=image.transformed(by:CGAffineTransform(scaleX:scale,y:scale))
            if let cg=ci.createCGImage(small,from:small.extent){
                let picture=UIImage(cgImage:cg)
                let rect=observation.map{ b in CGRect(x:(b.boundingBox.minX-crop.minX)/crop.width,y:(b.boundingBox.minY-crop.minY)/crop.height,width:b.boundingBox.width/crop.width,height:b.boundingBox.height/crop.height) }
                let label=lost ? "Obyekt yo‘qoldi — qayta belgilang" : (tracking ? (limited ? "Chegaraga yetdi" : "CENTER LOCK") : "Obyektni belgilang")
                ui{$0.preview=picture;$0.targetRect=rect;$0.edgeLimited=limited;$0.status=label}
            }
        }
    }
}
