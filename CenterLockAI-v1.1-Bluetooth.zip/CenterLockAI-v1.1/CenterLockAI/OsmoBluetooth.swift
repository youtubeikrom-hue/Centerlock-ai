import SwiftUI
import CoreBluetooth
import UIKit

final class OsmoBluetooth: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    struct Device: Identifiable {
        let id: UUID
        let name: String
        let rssi: Int?
    }
    @Published private(set) var devices: [Device] = []
    @Published private(set) var status = "Bluetooth o‘chiq yoki hali ochilmagan"
    @Published private(set) var connectedName: String?
    @Published private(set) var scanning = false
    @Published private(set) var connecting = false
    @Published private(set) var serviceIDs: [String] = []
    @Published private(set) var battery: Int?
    @Published var autoReconnect = UserDefaults.standard.object(forKey: "osmoAutoReconnect") as? Bool ?? true {
        didSet { UserDefaults.standard.set(autoReconnect, forKey: "osmoAutoReconnect") }
    }
    private var central: CBCentralManager?
    private var peripherals: [UUID: CBPeripheral] = [:]
    private var active: CBPeripheral?
    private var scanTimeout: DispatchWorkItem?
    private var connectTimeout: DispatchWorkItem?
    private var retry: DispatchWorkItem?
    private var retryCount = 0
    private var desiredID: UUID?
    private var userDisconnect = false
    private var foreground = true
    private let batteryService = CBUUID(string: "180F")
    private let batteryLevel = CBUUID(string: "2A19")

    func start() {
        if central == nil { central = CBCentralManager(delegate: self, queue: .main) }
        else if central?.state == .poweredOn && active == nil && !scanning { scan() }
    }
    func setForeground(_ enabled: Bool) {
        foreground = enabled
        if !enabled { stopScan(); retry?.cancel() }
        else if central?.state == .poweredOn && active == nil && desiredID != nil && autoReconnect && !userDisconnect { retryCount = 0; scheduleRetry() }
    }
    private func isOsmo(_ name: String) -> Bool {
        let n = name.uppercased().replacingOccurrences(of: " ", with: "")
        return n.hasPrefix("OM7") || n.contains("OSMOMOBILE7") || n.hasPrefix("DJIOM7")
    }
    func scan() {
        guard let central, central.state == .poweredOn else { startIfNeeded(); return }
        guard active == nil else { return }
        retry?.cancel(); scanTimeout?.cancel()
        devices = []; scanning = true; status = "Osmo 7 / 7P qidirilmoqda…"
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
        let work = DispatchWorkItem { [weak self] in
            guard let self, self.scanning else { return }
            self.stopScan(); self.status = self.devices.isEmpty ? "Osmo topilmadi. Qurilmani yoqing va qayta qidiring." : "Qurilmani tanlang"
        }
        scanTimeout = work; DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: work)
    }
    private func startIfNeeded() { if central == nil { start() } }
    func stopScan() { central?.stopScan(); scanning = false; scanTimeout?.cancel() }
    func connect(_ id: UUID) {
        guard let p = peripherals[id], active == nil, central?.state == .poweredOn else { return }
        userDisconnect = false; desiredID = id; retryCount = 0
        beginConnection(p)
    }
    private func beginConnection(_ p: CBPeripheral) {
        guard let central, central.state == .poweredOn, active == nil else { return }
        stopScan(); retry?.cancel(); active = p; p.delegate = self
        connecting = true; status = "Bluetooth ulanmoqda…"; serviceIDs = []; battery = nil
        central.connect(p, options: nil)
        connectTimeout?.cancel()
        let work = DispatchWorkItem { [weak self, weak p] in
            guard let self, let p, self.active?.identifier == p.identifier, self.connecting else { return }
            self.status = "Ulanish vaqti tugadi"; self.central?.cancelPeripheralConnection(p)
        }
        connectTimeout = work; DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: work)
    }
    func disconnect() {
        userDisconnect = true; desiredID = nil; retry?.cancel(); connectTimeout?.cancel(); stopScan()
        UserDefaults.standard.removeObject(forKey: "lastOsmoID")
        if let active { status = "Uzilmoqda…"; central?.cancelPeripheralConnection(active) }
        else { status = "Ulanmagan" }
    }
    private func scheduleRetry() {
        guard foreground, autoReconnect, !userDisconnect, let id = desiredID, retryCount < 3,
              central?.state == .poweredOn else { return }
        retryCount += 1; status = "Qayta ulanish (\(retryCount)/3)…"
        retry?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self, self.foreground, self.autoReconnect, !self.userDisconnect, self.active == nil, self.desiredID == id else { return }
            if let p = self.peripherals[id] ?? self.central?.retrievePeripherals(withIdentifiers: [id]).first { self.beginConnection(p) }
            else { self.scan() }
        }
        retry = work; DispatchQueue.main.asyncAfter(deadline: .now() + Double(retryCount) * 2, execute: work)
    }
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            status = "Bluetooth tayyor"
            if autoReconnect, !userDisconnect, let stored = UserDefaults.standard.string(forKey: "lastOsmoID"), let id = UUID(uuidString: stored), let p = central.retrievePeripherals(withIdentifiers: [id]).first {
                desiredID = id; peripherals[id] = p; retryCount = 0; beginConnection(p)
            } else if foreground { scan() }
        case .poweredOff: resetLink(); status = "Bluetooth’ni yoqing"
        case .unauthorized: resetLink(); status = "Bluetooth ruxsatini Settings’da bering"
        case .unsupported: resetLink(); status = "Bluetooth LE mavjud emas"
        case .resetting: resetLink(); status = "Bluetooth qayta ishga tushmoqda"
        default: status = "Bluetooth holati aniqlanmoqda…"
        }
    }
    private func resetLink() {
        stopScan(); connectTimeout?.cancel(); retry?.cancel(); active = nil; connecting = false; connectedName = nil; battery = nil; serviceIDs = []
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? peripheral.name ?? ""
        guard isOsmo(name) else { return }
        peripherals[peripheral.identifier] = peripheral
        let device = Device(id: peripheral.identifier, name: name, rssi: RSSI.intValue == 127 ? nil : RSSI.intValue)
        if let index = devices.firstIndex(where: { $0.id == device.id }) { devices[index] = device }
        else { devices.append(device) }
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        guard active?.identifier == peripheral.identifier else { central.cancelPeripheralConnection(peripheral); return }
        if userDisconnect { central.cancelPeripheralConnection(peripheral); return }
        connectTimeout?.cancel(); connecting = false; retryCount = 0
        connectedName = peripheral.name ?? devices.first(where: { $0.id == peripheral.identifier })?.name ?? "Osmo Mobile 7"
        status = "Bluetooth ulandi • motor boshqaruvi mavjud emas"
        UserDefaults.standard.set(peripheral.identifier.uuidString, forKey: "lastOsmoID")
        peripheral.discoverServices(nil)
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) { finish(peripheral, error: error) }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) { finish(peripheral, error: error) }
    private func finish(_ p: CBPeripheral, error: Error?) {
        guard active?.identifier == p.identifier else { return }
        connectTimeout?.cancel(); active = nil; connecting = false; connectedName = nil; battery = nil; serviceIDs = []
        status = userDisconnect ? "Ulanmagan" : "Aloqa uzildi" + (error.map { ": " + $0.localizedDescription } ?? "")
        scheduleRetry()
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard active?.identifier == peripheral.identifier, connectedName != nil else { return }
        serviceIDs = peripheral.services?.map { $0.uuid.uuidString }.sorted() ?? []
        if let service = peripheral.services?.first(where: { $0.uuid == batteryService }) {
            peripheral.discoverCharacteristics([batteryLevel], for: service)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard active?.identifier == peripheral.identifier, connectedName != nil, error == nil else { return }
        if let c = service.characteristics?.first(where: { $0.uuid == batteryLevel }) {
            if c.properties.contains(.read) { peripheral.readValue(for: c) }
            if c.properties.contains(.notify) { peripheral.setNotifyValue(true, for: c) }
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard active?.identifier == peripheral.identifier, error == nil, characteristic.uuid == batteryLevel,
              let value = characteristic.value?.first, value <= 100 else { return }
        battery = Int(value)
    }
}

struct OsmoConnectionScreen: View {
    @ObservedObject var osmo: OsmoBluetooth
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                Section("Ulanish holati") {
                    Label(osmo.status, systemImage: osmo.connectedName == nil ? "antenna.radiowaves.left.and.right" : "checkmark.circle.fill")
                    if let name = osmo.connectedName { Text(name).font(.headline) }
                    if let battery = osmo.battery { Text("Batareya: \(battery)%") }
                    if osmo.connecting || osmo.scanning { ProgressView() }
                    Toggle("Avtomatik qayta ulanish", isOn: $osmo.autoReconnect)
                    if osmo.connectedName != nil || osmo.connecting { Button("Ulanishni uzish", role: .destructive) { osmo.disconnect() } }
                    else { Button(osmo.scanning ? "Qidirishni to‘xtatish" : "Osmo qidirish") { osmo.scanning ? osmo.stopScan() : osmo.scan() } }
                }
                if osmo.connectedName == nil && !osmo.connecting {
                    Section("Topilgan qurilmalar") {
                        if osmo.devices.isEmpty { Text("Hozircha qurilma yo‘q").foregroundStyle(.secondary) }
                        ForEach(osmo.devices) { device in
                            Button { osmo.connect(device.id) } label: {
                                HStack { Image(systemName: "camera"); Text(device.name); Spacer(); if let rssi = device.rssi { Text("\(rssi) dBm").font(.caption).foregroundStyle(.secondary) }; Image(systemName: "chevron.right") }
                            }
                        }
                    }
                }
                Section("DJI OM Multifunctional Module") {
                    Text("Modul bo‘lsa, uni Osmo’ga o‘rnating va DJI ko‘rsatmasiga muvofiq odam kuzatuvini yoqing. Modul motorlarni o‘zi boshqaradi. CenterLock raqamli markazlashtirishni davom ettiradi.")
                    Link("DJI rasmiy qo‘llanmasi", destination: URL(string: "https://www.dji.com/osmo-mobile-7-series/faq")!)
                }
                Section("Yordam") {
                    Text("Osmo’ni yoqing, DJI Mimo’ni yoping. Bluetooth ruxsatini bering. Qurilma nomi OM7 yoki OM7P bo‘lishi mumkin. Ulanish ishlamasa, iPhone Settings → Bluetooth orqali tekshiring.")
                    Button("Ilova ruxsatlari") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }
                    Text("Bluetooth aloqa motorlarga buyruq yuborish degani emas. Ushbu versiyada DJI motor protokoli yo‘q. Batareya faqat qurilma standart BLE batareya xizmatini taqdim etsa ko‘rinadi.").foregroundStyle(.secondary)
                }
                if !osmo.serviceIDs.isEmpty { Section("Aniqlangan BLE xizmatlari") { ForEach(osmo.serviceIDs, id: \.self) { Text($0).font(.caption.monospaced()) } } }
            }.navigationTitle("Osmo Mobile 7").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Tayyor") { dismiss() } } }
        }.onAppear { osmo.start() }
    }
}
