import AVFoundation
import CoreImage
import Foundation

final class MovieWriter {
    private let writer: AVAssetWriter
    private let video: AVAssetWriterInput
    private var audio: AVAssetWriterInput? = nil
    private let adaptor: AVAssetWriterInputPixelBufferAdaptor
    private let url: URL
    private let width: Int
    private let height: Int
    private var started = false
    private var startTime = CMTime.invalid
    private var lastTime = CMTime.invalid
    private let color = CGColorSpace(name:CGColorSpace.sRGB)!
    private static func error(_ message:String)->NSError { NSError(domain:"CenterLock",code:1,userInfo:[NSLocalizedDescriptionKey:message]) }
    init(width:Int,height:Int,fps:Int,audio enabled:Bool) throws {
        self.width=width;self.height=height
        let folder=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0]
        url=folder.appendingPathComponent("CenterLock-\(UUID().uuidString).mp4")
        writer=try AVAssetWriter(outputURL:url,fileType:.mp4)
        video=AVAssetWriterInput(mediaType:.video,outputSettings:[AVVideoCodecKey:AVVideoCodecType.h264,AVVideoWidthKey:width,AVVideoHeightKey:height,AVVideoCompressionPropertiesKey:[AVVideoAverageBitRateKey:fps==60 ? 20_000_000 : 12_000_000,AVVideoExpectedSourceFrameRateKey:fps]])
        video.expectsMediaDataInRealTime=true
        adaptor=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:video,sourcePixelBufferAttributes:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32BGRA,kCVPixelBufferWidthKey as String:width,kCVPixelBufferHeightKey as String:height,kCVPixelBufferIOSurfacePropertiesKey as String:[:] as [String:Any]])
        guard writer.canAdd(video) else {throw Self.error("Video encoder mavjud emas")};writer.add(video)
        if enabled {
            let a=AVAssetWriterInput(mediaType:.audio,outputSettings:[AVFormatIDKey:kAudioFormatMPEG4AAC,AVSampleRateKey:44100,AVNumberOfChannelsKey:1,AVEncoderBitRateKey:96000]);a.expectsMediaDataInRealTime=true
            if writer.canAdd(a){writer.add(a);audio=a}else{audio=nil}
        }else{audio=nil}
    }
    func appendVideo(_ frame:CIImage,pts:CMTime,context:CIContext) throws {
        if !started {guard writer.startWriting() else{throw writer.error ?? Self.error("Video boshlanmadi")};writer.startSession(atSourceTime:pts);startTime=pts;started=true}
        guard writer.status == .writing else {throw writer.error ?? Self.error("Video yozish xatosi")}
        guard video.isReadyForMoreMediaData,!lastTime.isValid || pts>lastTime else{return}
        guard let pool=adaptor.pixelBufferPool else{throw Self.error("Video xotirasi ajratilmadi")}
        var buffer:CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault,pool,&buffer)==kCVReturnSuccess,let buffer else{return}
        let extent=frame.extent
        let resized=frame.transformed(by:CGAffineTransform(translationX:-extent.minX,y:-extent.minY)).transformed(by:CGAffineTransform(scaleX:CGFloat(width)/extent.width,y:CGFloat(height)/extent.height))
        context.render(resized,to:buffer,bounds:CGRect(x:0,y:0,width:width,height:height),colorSpace:color)
        guard adaptor.append(buffer,withPresentationTime:pts) else {throw writer.error ?? Self.error("Kadr yozilmadi")};lastTime=pts
    }
    func appendAudio(_ sample:CMSampleBuffer){guard started,writer.status == .writing,let audio,audio.isReadyForMoreMediaData,CMSampleBufferGetPresentationTimeStamp(sample)>=startTime else{return};_ = audio.append(sample)}
    func cancel(){writer.cancelWriting();try? FileManager.default.removeItem(at:url)}
    func finish(_ completion:@escaping(Result<URL,Error>)->Void){
        guard started,lastTime.isValid,writer.status == .writing else {let err=writer.error ?? Self.error("Video juda qisqa yoki yozilmadi");cancel();completion(.failure(err));return}
        video.markAsFinished();audio?.markAsFinished()
        writer.finishWriting { [self] in if writer.status == .completed {completion(.success(url))} else {completion(.failure(writer.error ?? Self.error("Video yakunlanmadi")))}}
    }
}
