import SwiftUI
import AVFoundation
import Vision
import CoreImage
import Photos
import UIKit

@main struct CenterLockApp: App {
    var body: some Scene { WindowGroup { CameraScreen().preferredColorScheme(.dark) } }
}

struct CameraScreen: View {
    @StateObject private var camera = CameraEngine()
    @StateObject private var osmo = OsmoBluetooth()
    @State private var osmoSheet = false
    @State private var start: CGPoint? = nil
    @State private var drag: CGRect? = nil
    @State private var settings = false
    @Environment(\.scenePhase) private var phase
    private let accent = Color(red: 0.36, green: 0.95, blue: 0.63)
    var body: some View {
        GeometryReader { geo in
            VStack(spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("CENTERLOCK").font(.system(size: 22, weight: .black, design: .rounded)).tracking(2)
                        Text("AI CAMERA  /  OFFLINE").font(.system(size: 10, weight: .semibold, design: .monospaced)).foregroundStyle(accent)
                    }
                    Spacer()
                    Button { osmoSheet = true } label: {
                        Image(systemName: osmo.connectedName == nil ? "antenna.radiowaves.left.and.right" : "checkmark.circle.fill")
                            .foregroundStyle(osmo.connectedName == nil ? Color.secondary : accent).font(.title2).padding(8)
                    }.accessibilityLabel("Osmo Bluetooth")
                    Button { settings = true } label: { Image(systemName: "slider.horizontal.3").font(.title2).padding(12) }.disabled(camera.recording || camera.saving)
                }.padding(.horizontal, 18)
                HStack {
                    Circle().fill(camera.recording ? .red : accent).frame(width: 8, height: 8)
                    Text(camera.recording ? "REC  \(camera.elapsedText)" : camera.status).lineLimit(2)
                    Spacer()
                    Text("\(camera.fps) FPS  •  FHD")
                    if osmo.connectedName != nil { Image(systemName: "link").foregroundStyle(accent).accessibilityLabel("Osmo Bluetooth ulangan") }
                }.font(.system(size: 11, weight: .medium, design: .monospaced)).padding(.horizontal, 18)
                let ratio: CGFloat = camera.landscape ? 16/9 : 9/16
                let available = max(120, geo.size.height - 250)
                let w = min(geo.size.width - 24, available * ratio)
                let h = w / ratio
                ZStack {
                    Color.black
                    if let frame = camera.preview { Image(uiImage: frame).resizable().frame(width: w, height: h) }
                    Path { p in
                        p.move(to: CGPoint(x: w/2-13, y: h/2)); p.addLine(to: CGPoint(x: w/2+13, y: h/2))
                        p.move(to: CGPoint(x: w/2, y: h/2-13)); p.addLine(to: CGPoint(x: w/2, y: h/2+13))
                    }.stroke(.white.opacity(0.65), lineWidth: 1)
                    if let r = camera.targetRect {
                        Rectangle().stroke(camera.edgeLimited ? Color.orange : accent, lineWidth: 2)
                            .frame(width: max(1,r.width*w), height: max(1,r.height*h))
                            .position(x: r.midX*w, y: (1-r.midY)*h)
                    }
                    if let r = drag {
                        Rectangle().stroke(accent, style: StrokeStyle(lineWidth: 2, dash: [5,3]))
                            .frame(width: r.width, height: r.height).position(x: r.midX,y:r.midY)
                    }
                    if camera.preview == nil { ProgressView().tint(accent) }
                }
                .frame(width: w,height: h).clipped().clipShape(RoundedRectangle(cornerRadius: 14))
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local).onChanged { v in
                    if start == nil { start = v.startLocation }
                    let s = start ?? v.startLocation
                    drag = CGRect(x:min(s.x,v.location.x),y:min(s.y,v.location.y),width:abs(s.x-v.location.x),height:abs(s.y-v.location.y))
                }.onEnded { v in
                    var r = drag ?? .zero
                    if r.width < 12 || r.height < 12 { r = CGRect(x:v.location.x-w*0.10,y:v.location.y-h*0.10,width:w*0.20,height:h*0.20) }
                    let normalized = CGRect(x:r.minX/w,y:1-r.maxY/h,width:r.width/w,height:r.height/h).intersection(CGRect(x:0,y:0,width:1,height:1))
                    if !normalized.isNull { camera.select(normalized) }
                    start = nil; drag = nil
                })
                Text(camera.edgeLimited ? "Kadr chegarasi — kamerani obyekt tomon buring" : "Obyektni bosing yoki atrofini chizing")
                    .font(.caption).foregroundStyle(camera.edgeLimited ? .orange : .secondary).multilineTextAlignment(.center)
                HStack(spacing: 12) {
                    Button { camera.clearTarget() } label: { Label("Reset", systemImage: "scope").frame(maxWidth: .infinity) }.buttonStyle(.bordered)
                    Button { camera.recording ? camera.stopRecording() : camera.startRecording() } label: {
                        ZStack { Circle().stroke(.white,lineWidth:3).frame(width:64,height:64)
                            RoundedRectangle(cornerRadius: camera.recording ? 7 : 27).fill(.red).frame(width:camera.recording ? 28 : 52,height:camera.recording ? 28 : 52) }
                    }.disabled(camera.saving || camera.preview == nil)
                    Button { camera.toggleFormat() } label: { Label(camera.landscape ? "16:9" : "9:16", systemImage: "rectangle.rotate").frame(maxWidth: .infinity) }.buttonStyle(.bordered).disabled(camera.recording || camera.saving)
                }.padding(.horizontal, 18)
                if camera.saving { ProgressView("Video saqlanmoqda…").font(.caption) }
                Spacer(minLength: 0)
            }.padding(.top, 8).frame(maxWidth: .infinity,maxHeight: .infinity).background(Color.black)
        }
        .task { await camera.prepare() }
        .onChange(of: phase) { newPhase in if newPhase == .background { camera.suspend(); osmo.setForeground(false) } else if newPhase == .active { camera.resume(); osmo.setForeground(true) } }
        .sheet(isPresented: $osmoSheet) { OsmoConnectionScreen(osmo: osmo) }
        .sheet(isPresented: $settings) {
            NavigationStack {
                Form {
                    Section("Video") {
                        Picker("FPS", selection: Binding(get:{camera.fps},set:{camera.changeFPS($0)})) { Text("30").tag(30); Text("60").tag(60) }.pickerStyle(.segmented)
                        Picker("Tracking zoom",selection: Binding(get:{camera.zoom},set:{camera.changeZoom($0)})) { Text("1.3×").tag(1.3); Text("1.6×").tag(1.6); Text("2×").tag(2.0) }.pickerStyle(.segmented)
                        Toggle("Silliq kuzatish",isOn:Binding(get:{camera.smooth},set:{camera.changeSmooth($0)}))
                    }
                    Section("Osmo Mobile 7") {
                        Text("Bluetooth ulanishi uchun asosiy ekrandagi antenna tugmasini bosing. Osmo 7 — stabilizator sifatida ishlaydi. DJI OM Multifunctional Module bo‘lsa, odamni fizik kuzatish modul orqali amalga oshadi. Ilova motorlarga bevosita Bluetooth buyruqlarini yubormaydi.")
                        Text("Raqamli Center Lock faqat kamera ko‘rib turgan hudud ichida ishlaydi. Obyekt kadrdan chiqsa, qayta belgilang.")
                    }
                    Section("Saqlash") { Text("Full HD H.264 video. Mikrofon ruxsat berilsa, audio ham yoziladi. Natija Photos ilovasiga saqlanadi.") }
                }.navigationTitle("Sozlamalar").toolbar { ToolbarItem(placement:.confirmationAction) { Button("Tayyor") { settings = false } } }
            }
        }
        .alert("CenterLock",isPresented:Binding(get:{camera.message != nil},set:{if !$0 {camera.message=nil}})) { Button("OK") {camera.message=nil} } message: { Text(camera.message ?? "") }
    }
}
