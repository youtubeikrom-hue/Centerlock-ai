# CenterLock AI — iPhone kamera ilovasi (1.1)

SwiftUI, Apple Vision, AVFoundation, Core Image, Photos. Internet yoki tashqi API talab qilmaydi. iOS 16+ uchun, iPhone 13 Pro maqsadli qurilma.

## Nimalar kiritilgan
- Jonli orqa kamera, obyektni bosish yoki to'rtburchak chizish bilan tanlash.
- Apple Vision orqali ixtiyoriy teksturali obyektning to'rtburchagini kuzatish.
- Center Lock: obyekt markaziga qarab raqamli crop, natija preview va yozilgan MP4 videoda bir xil.
- 1.3x, 1.6x, 2x raqamli kuzatuv zoomi, ixtiyoriy silliqlash.
- 1080p H.264 chiqish (9:16 yoki 16:9), 30 yoki 60 FPS maqsadli capture. 4K input mavjud bo'lsa tanlanadi; bu 4K eksport emas. Haqiqiy FPS apparat va yuklamaga bog'liq.
- Mikrofon ruxsati bilan AAC audio; Photos'ga saqlash. Photos ruxsati yo'q bo'lsa, MP4 Files → On My iPhone → CenterLock AI ichida qoladi.
- Obyekt yo'qolganda ogohlantirish va qayta tanlash; qo'lda Reset.

## Muhim cheklov
Bluetooth LE ulanish sahifasi mavjud: OM7/OM7P nomi bo‘yicha qidirish, ulash, uzish, 3 martagacha qayta ulanish, oxirgi qurilmani eslash, GATT xizmatlarini ko‘rish, standart batareya xizmatini o‘qish (mavjud bo‘lsa). Ulanish sahifasini birinchi marta ochganda iOS Bluetooth ruxsatini so‘raydi.

Osmo Mobile 7 motorlari uchun tasdiqlangan ochiq boshqaruv protokoli yoki SDK topilmadi. Ushbu ilova motorlarni Bluetooth orqali burmaydi. Oddiy Osmo 7 passiv stabilizator sifatida ishlaydi; DJI OM Multifunctional Module ulangan bo'lsa, uning mustaqil odam kuzatish funksiyasi boshqa kamera ilovalari bilan ishlaydi. Modul tanlangan ixtiyoriy obyektni aynan ilovadan boshqarmaydi. Raqamli crop sensor ko'rayotgan chegaradan chiqolmaydi; tez harakat, to'siq, tracking xatosi va crop chegarasi markazdan siljishga olib kelishi mumkin. Silliq rejimda qasddan kichik kechikish bo'ladi. Obyekt yo'qolsa avtomatik qayta identifikatsiya yo'q.

## O'rnatish
1. Mac kompyuterda Xcode (16 yoki keyingi mos versiya) o'rnating. iPhone versiyasiga mos Xcode kerak.
2. ZIP faylni oching va CenterLockAI.xcodeproj faylini Xcode bilan oching.
3. Xcode → Settings → Accounts orqali Apple Account qo'shing.
4. CenterLockAI target → Signing & Capabilities → Automatically manage signing → Team tanlang. Bundle Identifier band bo'lsa noyob qiymatga o'zgartiring.
5. iPhone'ni USB orqali ulang, Trust tugmasini bosing. Xcode'da iPhone'ni Run destination sifatida tanlang. Kerak bo'lsa iPhone Settings → Privacy & Security → Developer Mode ni yoqing.
6. Run (⌘R) tugmasi bilan imzolangan ilovani telefonga o'rnating. Shaxsiy bepul imzolash cheklangan muddatli (odatda 7 kun).
7. Kamera va mikrofon ruxsatlarini bering. Osmo'ga telefonni joylang, obyektni belgilang, qizil yozish tugmasini bosing. 16:9 uchun telefonni gorizontal tuting (kamera yuqori chap tomonda bo'lishi kerak; agar teskari ko'rinsa telefonni boshqa tomonga aylantiring).

## Loyiha holati
Bu Xcode'da ochiladigan manba kodi loyihasi, imzolangan IPA emas. Swift sintaksisi Linux Swift parser bilan tekshirildi; bu iOS SDK bilan kompilyatsiya yoki real qurilmada ishlash sinovi emas. Ushbu muhitda macOS/Xcode va fizik Osmo 7 yo'q. Shuning uchun iOS kompilyatsiyasi, iOS qurilmasi va DJI bilan ishlash tasdiqlanmagan. Xcode va signing o'rnatish uchun zarur; Windows o'zi native iOS build bera olmaydi.

## Rasmiy ma'lumotlar
- https://developer.apple.com/documentation/vision/vntrackobjectrequest
- https://developer.apple.com/documentation/avfoundation/avassetwriter
- https://www.dji.com/support/product/osmo-mobile-7
- https://www.dji.com/osmo-mobile-7-series/faq

## Bluetooth foydalanish
1. Osmo’ni yoqing va DJI Mimo’ni yoping.
2. CenterLock asosiy ekrandagi antenna belgisini bosing, Bluetooth ruxsatini bering.
3. Topilgan OM7/OM7P qurilmasini tanlang. Ulanish holati CoreBluetooth callback asosida ko‘rsatiladi.
4. Agar topilmasa, iPhone Bluetooth sozlamalarini tekshiring. Ayrim firmware qurilmalari nomini reklama qilmasligi yoki uchinchi tomon ulanishini cheklashi mumkin.
5. DJI moduli bo‘lsa odam kuzatishini modulning o‘zidan yoqing. Bluetooth ulanishi motor boshqaruvini bermaydi.

OM7/7P uchun BLE aloqa fizik qurilmada tasdiqlanmagan. Reverse engineering manbasi https://github.com/alkersan/om-research eski OM2/3/4 qurilmalarida tekshirilgan; shu sababli noma’lum motor buyruqlari yuborilmaydi.
